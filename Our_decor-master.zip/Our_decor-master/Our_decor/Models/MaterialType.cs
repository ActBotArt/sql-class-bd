﻿namespace Our_decor.Models
{
    public class MaterialType
    {
        public int Id { get; set; }
        public string TypeName { get; set; }
        public decimal WastePercentage { get; set; }
    }
}