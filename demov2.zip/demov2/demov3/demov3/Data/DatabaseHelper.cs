using System;
using System.Collections.Generic;
using System.Data;
using Microsoft.Data.SqlClient;
using demov3.Models;

namespace demov3.Data
{
    /// <summary>
    /// Класс для работы с базой данных
    /// </summary>
    public class DatabaseHelper
    {
        private readonly string connectionString;

        public DatabaseHelper()
        {
            // Строка подключения к SQL Server Express
            connectionString = @"Data Source=Uz1ps\SQLEXPRESS;Initial Catalog=WallpaperProduction;Integrated Security=True;TrustServerCertificate=True";
        }

        /// <summary>
        /// Получение списка всех продуктов с рассчитанной стоимостью
        /// </summary>
        public List<Product> GetProducts()
        {
            var products = new List<Product>();
            
            try
            {
                using (var connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string query = "SELECT * FROM ProductsWithCost ORDER BY Article";
                    
                    using (var command = new SqlCommand(query, connection))
                    using (var reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            products.Add(new Product
                            {
                                Id = Convert.ToInt32(reader["Id"]),
                                Article = Convert.ToString(reader["Article"]),
                                ProductType = Convert.ToString(reader["ProductType"]),
                                Name = Convert.ToString(reader["Name"]),
                                Description = reader["Description"] == DBNull.Value ? "" : Convert.ToString(reader["Description"]),
                                MinPartnerCost = Convert.ToDecimal(reader["MinPartnerCost"]),
                                RollWidth = Convert.ToDecimal(reader["RollWidth"]),
                                MaterialCost = Convert.ToDecimal(reader["MaterialCost"]),
                                ProductionTime = Convert.ToInt32(reader["ProductionTime"]),
                                WorkshopNumber = Convert.ToInt32(reader["WorkshopNumber"]),
                                WorkersCount = Convert.ToInt32(reader["WorkersCount"])
                            });
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception($"Ошибка при получении списка продукции: {ex.Message}");
            }
            
            return products;
        }

        /// <summary>
        /// Получение продукта по ID
        /// </summary>
        public Product GetProductById(int id)
        {
            try
            {
                using (var connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string query = @"
                        SELECT p.*, pt.TypeName as ProductType 
                        FROM Products p 
                        INNER JOIN ProductTypes pt ON p.ProductTypeId = pt.Id 
                        WHERE p.Id = @Id";
                    
                    using (var command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@Id", id);
                        using (var reader = command.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                return new Product
                                {
                                    Id = Convert.ToInt32(reader["Id"]),
                                    Article = Convert.ToString(reader["Article"]),
                                    ProductTypeId = Convert.ToInt32(reader["ProductTypeId"]),
                                    ProductType = Convert.ToString(reader["ProductType"]),
                                    Name = Convert.ToString(reader["Name"]),
                                    Description = reader["Description"] == DBNull.Value ? "" : Convert.ToString(reader["Description"]),
                                    MinPartnerCost = Convert.ToDecimal(reader["MinPartnerCost"]),
                                    RollWidth = Convert.ToDecimal(reader["RollWidth"]),
                                    ProductionTime = Convert.ToInt32(reader["ProductionTime"]),
                                    WorkshopNumber = Convert.ToInt32(reader["WorkshopNumber"]),
                                    WorkersCount = Convert.ToInt32(reader["WorkersCount"])
                                };
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception($"Ошибка при получении продукта: {ex.Message}");
            }
            
            return null;
        }

        /// <summary>
        /// Получение списка типов продукции
        /// </summary>
        public List<ProductType> GetProductTypes()
        {
            var productTypes = new List<ProductType>();
            
            try
            {
                using (var connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string query = "SELECT * FROM ProductTypes ORDER BY TypeName";
                    
                    using (var command = new SqlCommand(query, connection))
                    using (var reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            productTypes.Add(new ProductType
                            {
                                Id = Convert.ToInt32(reader["Id"]),
                                TypeName = Convert.ToString(reader["TypeName"]),
                                Coefficient = Convert.ToDecimal(reader["Coefficient"])
                            });
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception($"Ошибка при получении типов продукции: {ex.Message}");
            }
            
            return productTypes;
        }

        /// <summary>
        /// Получение материалов для конкретного продукта
        /// </summary>
        public List<ProductMaterial> GetProductMaterials(int productId)
        {
            var materials = new List<ProductMaterial>();
            
            try
            {
                using (var connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string query = "SELECT * FROM ProductMaterialsView WHERE ProductId = @ProductId";
                    
                    using (var command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@ProductId", productId);
                        using (var reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                materials.Add(new ProductMaterial
                                {
                                    ProductId = Convert.ToInt32(reader["ProductId"]),
                                    Article = Convert.ToString(reader["Article"]),
                                    ProductName = Convert.ToString(reader["ProductName"]),
                                    MaterialName = Convert.ToString(reader["MaterialName"]),
                                    Quantity = Convert.ToDecimal(reader["Quantity"]),
                                    Unit = Convert.ToString(reader["Unit"]),
                                    Cost = Convert.ToDecimal(reader["Cost"]),
                                    TotalCost = Convert.ToDecimal(reader["TotalCost"])
                                });
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception($"Ошибка при получении материалов продукта: {ex.Message}");
            }
            
            return materials;
        }

        /// <summary>
        /// Добавление нового продукта
        /// </summary>
        public void AddProduct(Product product)
        {
            try
            {
                using (var connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string query = @"
                        INSERT INTO Products (Article, ProductTypeId, Name, Description, MinPartnerCost, RollWidth, ProductionTime, WorkshopNumber, WorkersCount)
                        VALUES (@Article, @ProductTypeId, @Name, @Description, @MinPartnerCost, @RollWidth, @ProductionTime, @WorkshopNumber, @WorkersCount)";
                    
                    using (var command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@Article", product.Article);
                        command.Parameters.AddWithValue("@ProductTypeId", product.ProductTypeId);
                        command.Parameters.AddWithValue("@Name", product.Name);
                        command.Parameters.AddWithValue("@Description", product.Description ?? "");
                        command.Parameters.AddWithValue("@MinPartnerCost", product.MinPartnerCost);
                        command.Parameters.AddWithValue("@RollWidth", product.RollWidth);
                        command.Parameters.AddWithValue("@ProductionTime", product.ProductionTime);
                        command.Parameters.AddWithValue("@WorkshopNumber", product.WorkshopNumber);
                        command.Parameters.AddWithValue("@WorkersCount", product.WorkersCount);
                        
                        command.ExecuteNonQuery();
                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception($"Ошибка при добавлении продукта: {ex.Message}");
            }
        }

        /// <summary>
        /// Обновление продукта
        /// </summary>
        public void UpdateProduct(Product product)
        {
            try
            {
                using (var connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string query = @"
                        UPDATE Products 
                        SET Article = @Article, ProductTypeId = @ProductTypeId, Name = @Name, 
                            Description = @Description, MinPartnerCost = @MinPartnerCost, 
                            RollWidth = @RollWidth, ProductionTime = @ProductionTime, 
                            WorkshopNumber = @WorkshopNumber, WorkersCount = @WorkersCount
                        WHERE Id = @Id";
                    
                    using (var command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@Id", product.Id);
                        command.Parameters.AddWithValue("@Article", product.Article);
                        command.Parameters.AddWithValue("@ProductTypeId", product.ProductTypeId);
                        command.Parameters.AddWithValue("@Name", product.Name);
                        command.Parameters.AddWithValue("@Description", product.Description ?? "");
                        command.Parameters.AddWithValue("@MinPartnerCost", product.MinPartnerCost);
                        command.Parameters.AddWithValue("@RollWidth", product.RollWidth);
                        command.Parameters.AddWithValue("@ProductionTime", product.ProductionTime);
                        command.Parameters.AddWithValue("@WorkshopNumber", product.WorkshopNumber);
                        command.Parameters.AddWithValue("@WorkersCount", product.WorkersCount);
                        
                        command.ExecuteNonQuery();
                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception($"Ошибка при обновлении продукта: {ex.Message}");
            }
        }

        /// <summary>
        /// Проверка подключения к базе данных
        /// </summary>
        public bool TestConnection()
        {
            try
            {
                using (var connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    return true;
                }
            }
            catch
            {
                return false;
            }
        }
    }
} 