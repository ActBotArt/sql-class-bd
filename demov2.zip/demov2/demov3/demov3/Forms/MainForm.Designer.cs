using System.Drawing;
using System.Windows.Forms;

namespace demov3.Forms
{
    partial class MainForm
    {
        private System.ComponentModel.IContainer components = null;
        private ListBox listBoxProducts;
        private Button btnAddProduct;
        private Button btnMaterials;
        private Label lblTitle;
        private Panel panelHeader;
        private Panel panelContent;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.panelHeader = new Panel();
            this.lblTitle = new Label();
            this.panelContent = new Panel();
            this.listBoxProducts = new ListBox();
            this.btnAddProduct = new Button();
            this.btnMaterials = new Button();
            this.panelHeader.SuspendLayout();
            this.panelContent.SuspendLayout();
            this.SuspendLayout();

            // panelHeader
            this.panelHeader.BackColor = ColorTranslator.FromHtml("#BBD9B2"); // Дополнительный фон
            this.panelHeader.Controls.Add(this.lblTitle);
            this.panelHeader.Dock = DockStyle.Top;
            this.panelHeader.Location = new Point(0, 0);
            this.panelHeader.Name = "panelHeader";
            this.panelHeader.Size = new Size(800, 80);
            this.panelHeader.TabIndex = 0;

            // lblTitle
            this.lblTitle.AutoSize = true;
            this.lblTitle.Font = new Font("Gabriola", 24F, FontStyle.Bold);
            this.lblTitle.ForeColor = ColorTranslator.FromHtml("#2D6033"); // Акцентирование внимания
            this.lblTitle.Location = new Point(20, 20);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new Size(400, 40);
            this.lblTitle.TabIndex = 0;
            this.lblTitle.Text = "Наш декор - Управление продукцией";

            // panelContent
            this.panelContent.BackColor = Color.White; // Основной фон
            this.panelContent.Controls.Add(this.listBoxProducts);
            this.panelContent.Controls.Add(this.btnAddProduct);
            this.panelContent.Controls.Add(this.btnMaterials);
            this.panelContent.Dock = DockStyle.Fill;
            this.panelContent.Location = new Point(0, 80);
            this.panelContent.Name = "panelContent";
            this.panelContent.Size = new Size(800, 520);
            this.panelContent.TabIndex = 1;

            // listBoxProducts
            this.listBoxProducts.BackColor = Color.White;
            this.listBoxProducts.Font = new Font("Gabriola", 14F);
            this.listBoxProducts.ForeColor = Color.Black;
            this.listBoxProducts.ItemHeight = 60;
            this.listBoxProducts.Location = new Point(20, 20);
            this.listBoxProducts.Name = "listBoxProducts";
            this.listBoxProducts.Size = new Size(600, 420);
            this.listBoxProducts.TabIndex = 0;
            this.listBoxProducts.DrawMode = DrawMode.OwnerDrawFixed;
            this.listBoxProducts.DrawItem += new DrawItemEventHandler(this.listBoxProducts_DrawItem);
            this.listBoxProducts.SelectedIndexChanged += new System.EventHandler(this.listBoxProducts_SelectedIndexChanged);
            this.listBoxProducts.DoubleClick += new System.EventHandler(this.listBoxProducts_DoubleClick);

            // btnAddProduct
            this.btnAddProduct.BackColor = ColorTranslator.FromHtml("#2D6033"); // Акцентирование внимания
            this.btnAddProduct.FlatStyle = FlatStyle.Flat;
            this.btnAddProduct.Font = new Font("Gabriola", 16F, FontStyle.Bold);
            this.btnAddProduct.ForeColor = Color.White;
            this.btnAddProduct.Location = new Point(640, 20);
            this.btnAddProduct.Name = "btnAddProduct";
            this.btnAddProduct.Size = new Size(140, 50);
            this.btnAddProduct.TabIndex = 1;
            this.btnAddProduct.Text = "Добавить";
            this.btnAddProduct.UseVisualStyleBackColor = false;
            this.btnAddProduct.Click += new System.EventHandler(this.btnAddProduct_Click);

            // btnMaterials
            this.btnMaterials.BackColor = ColorTranslator.FromHtml("#BBD9B2"); // Дополнительный фон
            this.btnMaterials.FlatStyle = FlatStyle.Flat;
            this.btnMaterials.Font = new Font("Gabriola", 16F, FontStyle.Bold);
            this.btnMaterials.ForeColor = ColorTranslator.FromHtml("#2D6033");
            this.btnMaterials.Location = new Point(640, 90);
            this.btnMaterials.Name = "btnMaterials";
            this.btnMaterials.Size = new Size(140, 50);
            this.btnMaterials.TabIndex = 2;
            this.btnMaterials.Text = "Материалы";
            this.btnMaterials.UseVisualStyleBackColor = false;
            this.btnMaterials.Enabled = false;
            this.btnMaterials.Click += new System.EventHandler(this.btnMaterials_Click);

            // MainForm
            this.AutoScaleDimensions = new SizeF(6F, 13F);
            this.AutoScaleMode = AutoScaleMode.Font;
            this.BackColor = Color.White;
            this.ClientSize = new Size(800, 600);
            this.Controls.Add(this.panelContent);
            this.Controls.Add(this.panelHeader);
            this.Font = new Font("Gabriola", 12F);
            this.Name = "MainForm";
            this.Text = "Наш декор - Система управления продукцией";
            this.panelHeader.ResumeLayout(false);
            this.panelHeader.PerformLayout();
            this.panelContent.ResumeLayout(false);
            this.ResumeLayout(false);
        }

        /// <summary>
        /// Настройка дополнительных элементов управления
        /// </summary>
        private void SetupControls()
        {
            // Дополнительная настройка элементов управления
        }

        /// <summary>
        /// Кастомная отрисовка элементов списка продукции
        /// </summary>
        private void listBoxProducts_DrawItem(object sender, DrawItemEventArgs e)
        {
            if (e.Index < 0) return;

            var listBox = sender as ListBox;
            var item = listBox.Items[e.Index] as ProductListItem;
            
            if (item == null) return;

            e.DrawBackground();

            // Цвета для отрисовки
            var textColor = Color.Black;
            var selectedColor = ColorTranslator.FromHtml("#BBD9B2");
            
            // Фон для выбранного элемента
            if ((e.State & DrawItemState.Selected) == DrawItemState.Selected)
            {
                using (var brush = new SolidBrush(selectedColor))
                {
                    e.Graphics.FillRectangle(brush, e.Bounds);
                }
            }

            // Отрисовка текста
            var font = new Font("Gabriola", 12F, FontStyle.Regular);
            var boldFont = new Font("Gabriola", 14F, FontStyle.Bold);
            
            var product = item.Product;
            var y = e.Bounds.Y + 5;
            
            // Артикул и название (жирным)
            var titleText = $"{product.Article} | {product.Name}";
            e.Graphics.DrawString(titleText, boldFont, new SolidBrush(textColor), e.Bounds.X + 5, y);
            y += 20;
            
            // Тип продукции
            var typeText = $"Тип: {product.ProductType}";
            e.Graphics.DrawString(typeText, font, new SolidBrush(textColor), e.Bounds.X + 5, y);
            y += 15;
            
            // Стоимость
            var costText = $"Минимальная стоимость для партнера: {product.MinPartnerCost:F2} р";
            e.Graphics.DrawString(costText, font, new SolidBrush(textColor), e.Bounds.X + 5, y);
            y += 15;
            
            // Ширина
            var widthText = $"Ширина: {product.RollWidth:F2} м";
            e.Graphics.DrawString(widthText, font, new SolidBrush(textColor), e.Bounds.X + 5, y);

            e.DrawFocusRectangle();
        }
    }
} 