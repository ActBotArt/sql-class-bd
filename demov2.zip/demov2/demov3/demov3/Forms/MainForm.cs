using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using demov3.Data;
using demov3.Models;

namespace demov3.Forms
{
    /// <summary>
    /// Главная форма приложения для отображения списка продукции
    /// </summary>
    public partial class MainForm : Form
    {
        private DatabaseHelper databaseHelper;
        private List<Product> products;

        public MainForm()
        {
            InitializeComponent();
            databaseHelper = new DatabaseHelper();
            SetupForm();
            LoadProducts();
        }

        /// <summary>
        /// Настройка внешнего вида формы согласно руководству по стилю
        /// </summary>
        private void SetupForm()
        {
            // Настройка формы
            this.Text = "Наш декор - Система управления продукцией";
            this.BackColor = Color.White; // Основной фон #FFFFFF
            this.Font = new Font("Gabriola", 12F, FontStyle.Regular);
            this.WindowState = FormWindowState.Maximized;
            this.StartPosition = FormStartPosition.CenterScreen;

            // Настройка элементов управления
            SetupControls();
        }

        /// <summary>
        /// Загрузка списка продукции из базы данных
        /// </summary>
        private void LoadProducts()
        {
            try
            {
                products = databaseHelper.GetProducts();
                UpdateProductList();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при загрузке продукции: {ex.Message}", 
                    "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        /// <summary>
        /// Обновление отображения списка продукции
        /// </summary>
        private void UpdateProductList()
        {
            listBoxProducts.Items.Clear();
            
            foreach (var product in products)
            {
                // Создание элемента списка согласно макету
                var item = new ProductListItem(product);
                listBoxProducts.Items.Add(item);
            }
        }

        /// <summary>
        /// Обработчик нажатия кнопки "Добавить продукт"
        /// </summary>
        private void btnAddProduct_Click(object sender, EventArgs e)
        {
            var productForm = new ProductForm();
            if (productForm.ShowDialog() == DialogResult.OK)
            {
                LoadProducts(); // Обновляем список после добавления
            }
        }

        /// <summary>
        /// Обработчик двойного клика по элементу списка для редактирования
        /// </summary>
        private void listBoxProducts_DoubleClick(object sender, EventArgs e)
        {
            if (listBoxProducts.SelectedItem is ProductListItem selectedItem)
            {
                var productForm = new ProductForm(selectedItem.Product);
                if (productForm.ShowDialog() == DialogResult.OK)
                {
                    LoadProducts(); // Обновляем список после редактирования
                }
            }
        }

        /// <summary>
        /// Обработчик нажатия кнопки "Материалы"
        /// </summary>
        private void btnMaterials_Click(object sender, EventArgs e)
        {
            if (listBoxProducts.SelectedItem is ProductListItem selectedItem)
            {
                var materialsForm = new MaterialsForm(selectedItem.Product);
                materialsForm.ShowDialog();
            }
            else
            {
                MessageBox.Show("Выберите продукт для просмотра материалов.", 
                    "Информация", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        /// <summary>
        /// Обработчик изменения выбранного элемента в списке
        /// </summary>
        private void listBoxProducts_SelectedIndexChanged(object sender, EventArgs e)
        {
            btnMaterials.Enabled = listBoxProducts.SelectedItem != null;
        }
    }

    /// <summary>
    /// Класс для отображения продукта в списке
    /// </summary>
    public class ProductListItem
    {
        public Product Product { get; }

        public ProductListItem(Product product)
        {
            Product = product;
        }

        public override string ToString()
        {
            return $"{Product.Article} | {Product.Name}\n" +
                   $"Тип: {Product.ProductType}\n" +
                   $"Минимальная стоимость для партнера: {Product.MinPartnerCost:F2} р\n" +
                   $"Ширина: {Product.RollWidth:F2} м";
        }
    }
} 