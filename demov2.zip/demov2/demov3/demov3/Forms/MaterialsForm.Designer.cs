using System.Drawing;
using System.Windows.Forms;

namespace demov3.Forms
{
    partial class MaterialsForm
    {
        private System.ComponentModel.IContainer components = null;
        private Panel panelHeader;
        private Label lblTitle;
        private Panel panelContent;
        private DataGridView dataGridViewMaterials;
        private Label lblTotalCost;
        private Button btnBack;
        private Button btnClose;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.panelHeader = new Panel();
            this.lblTitle = new Label();
            this.panelContent = new Panel();
            this.dataGridViewMaterials = new DataGridView();
            this.lblTotalCost = new Label();
            this.btnBack = new Button();
            this.btnClose = new Button();
            this.panelHeader.SuspendLayout();
            this.panelContent.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewMaterials)).BeginInit();
            this.SuspendLayout();

            // panelHeader
            this.panelHeader.BackColor = ColorTranslator.FromHtml("#BBD9B2");
            this.panelHeader.Controls.Add(this.lblTitle);
            this.panelHeader.Dock = DockStyle.Top;
            this.panelHeader.Location = new Point(0, 0);
            this.panelHeader.Name = "panelHeader";
            this.panelHeader.Size = new Size(700, 60);
            this.panelHeader.TabIndex = 0;

            // lblTitle
            this.lblTitle.AutoSize = true;
            this.lblTitle.Font = new Font("Gabriola", 18F, FontStyle.Bold);
            this.lblTitle.ForeColor = ColorTranslator.FromHtml("#2D6033");
            this.lblTitle.Location = new Point(20, 15);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new Size(200, 30);
            this.lblTitle.TabIndex = 0;
            this.lblTitle.Text = "Материалы продукта";

            // panelContent
            this.panelContent.BackColor = Color.White;
            this.panelContent.Controls.Add(this.dataGridViewMaterials);
            this.panelContent.Controls.Add(this.lblTotalCost);
            this.panelContent.Controls.Add(this.btnBack);
            this.panelContent.Controls.Add(this.btnClose);
            this.panelContent.Dock = DockStyle.Fill;
            this.panelContent.Location = new Point(0, 60);
            this.panelContent.Name = "panelContent";
            this.panelContent.Size = new Size(700, 440);
            this.panelContent.TabIndex = 1;

            // dataGridViewMaterials
            this.dataGridViewMaterials.AllowUserToAddRows = false;
            this.dataGridViewMaterials.AllowUserToDeleteRows = false;
            this.dataGridViewMaterials.BackgroundColor = Color.White;
            this.dataGridViewMaterials.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewMaterials.Location = new Point(20, 20);
            this.dataGridViewMaterials.Name = "dataGridViewMaterials";
            this.dataGridViewMaterials.ReadOnly = true;
            this.dataGridViewMaterials.RowHeadersVisible = false;
            this.dataGridViewMaterials.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewMaterials.Size = new Size(660, 320);
            this.dataGridViewMaterials.TabIndex = 0;
            this.dataGridViewMaterials.Font = new Font("Gabriola", 12F);

            // Настройка колонок
            this.dataGridViewMaterials.Columns.Add("MaterialName", "Наименование материала");
            this.dataGridViewMaterials.Columns.Add("Quantity", "Количество");
            this.dataGridViewMaterials.Columns.Add("Unit", "Единица измерения");
            this.dataGridViewMaterials.Columns.Add("Cost", "Стоимость за единицу (р)");
            this.dataGridViewMaterials.Columns.Add("TotalCost", "Общая стоимость (р)");

            // Настройка ширины колонок
            this.dataGridViewMaterials.Columns[0].Width = 250; // Наименование
            this.dataGridViewMaterials.Columns[1].Width = 100; // Количество
            this.dataGridViewMaterials.Columns[2].Width = 120; // Единица
            this.dataGridViewMaterials.Columns[3].Width = 120; // Стоимость за единицу
            this.dataGridViewMaterials.Columns[4].Width = 120; // Общая стоимость

            // Настройка стиля заголовков
            this.dataGridViewMaterials.ColumnHeadersDefaultCellStyle.BackColor = ColorTranslator.FromHtml("#BBD9B2");
            this.dataGridViewMaterials.ColumnHeadersDefaultCellStyle.ForeColor = ColorTranslator.FromHtml("#2D6033");
            this.dataGridViewMaterials.ColumnHeadersDefaultCellStyle.Font = new Font("Gabriola", 14F, FontStyle.Bold);

            // lblTotalCost
            this.lblTotalCost.AutoSize = true;
            this.lblTotalCost.Font = new Font("Gabriola", 16F, FontStyle.Bold);
            this.lblTotalCost.ForeColor = ColorTranslator.FromHtml("#2D6033");
            this.lblTotalCost.Location = new Point(20, 360);
            this.lblTotalCost.Name = "lblTotalCost";
            this.lblTotalCost.Size = new Size(250, 30);
            this.lblTotalCost.TabIndex = 1;
            this.lblTotalCost.Text = "Общая стоимость материалов: 0.00 р";

            // btnBack
            this.btnBack.BackColor = ColorTranslator.FromHtml("#BBD9B2");
            this.btnBack.FlatStyle = FlatStyle.Flat;
            this.btnBack.Font = new Font("Gabriola", 14F, FontStyle.Bold);
            this.btnBack.ForeColor = ColorTranslator.FromHtml("#2D6033");
            this.btnBack.Location = new Point(450, 360);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new Size(100, 40);
            this.btnBack.TabIndex = 2;
            this.btnBack.Text = "Назад";
            this.btnBack.UseVisualStyleBackColor = false;
            this.btnBack.Click += new System.EventHandler(this.btnBack_Click);

            // btnClose
            this.btnClose.BackColor = ColorTranslator.FromHtml("#2D6033");
            this.btnClose.FlatStyle = FlatStyle.Flat;
            this.btnClose.Font = new Font("Gabriola", 14F, FontStyle.Bold);
            this.btnClose.ForeColor = Color.White;
            this.btnClose.Location = new Point(580, 360);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new Size(100, 40);
            this.btnClose.TabIndex = 3;
            this.btnClose.Text = "Закрыть";
            this.btnClose.UseVisualStyleBackColor = false;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);

            // MaterialsForm
            this.AutoScaleDimensions = new SizeF(6F, 13F);
            this.AutoScaleMode = AutoScaleMode.Font;
            this.BackColor = Color.White;
            this.ClientSize = new Size(700, 500);
            this.Controls.Add(this.panelContent);
            this.Controls.Add(this.panelHeader);
            this.Font = new Font("Gabriola", 12F);
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "MaterialsForm";
            this.StartPosition = FormStartPosition.CenterParent;
            this.Text = "Материалы";
            this.panelHeader.ResumeLayout(false);
            this.panelHeader.PerformLayout();
            this.panelContent.ResumeLayout(false);
            this.panelContent.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewMaterials)).EndInit();
            this.ResumeLayout(false);
        }
    }
} 