using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
using demov3.Data;
using demov3.Models;

namespace demov3.Forms
{
    /// <summary>
    /// Форма для отображения материалов продукта
    /// </summary>
    public partial class MaterialsForm : Form
    {
        private DatabaseHelper databaseHelper;
        private Product currentProduct;
        private List<ProductMaterial> materials;

        public MaterialsForm(Product product)
        {
            InitializeComponent();
            databaseHelper = new DatabaseHelper();
            currentProduct = product;
            
            SetupForm();
            LoadMaterials();
        }

        /// <summary>
        /// Настройка внешнего вида формы
        /// </summary>
        private void SetupForm()
        {
            this.Text = $"Материалы - {currentProduct.Article} {currentProduct.Name}";
            this.BackColor = Color.White;
            this.Font = new Font("Gabriola", 12F, FontStyle.Regular);
            this.StartPosition = FormStartPosition.CenterParent;
            this.WindowState = FormWindowState.Normal;
            
            // Обновление заголовка
            lblTitle.Text = $"Материалы для {currentProduct.Article}";
        }

        /// <summary>
        /// Загрузка материалов продукта
        /// </summary>
        private void LoadMaterials()
        {
            try
            {
                materials = databaseHelper.GetProductMaterials(currentProduct.Id);
                UpdateMaterialsList();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при загрузке материалов: {ex.Message}", 
                    "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        /// <summary>
        /// Обновление отображения списка материалов
        /// </summary>
        private void UpdateMaterialsList()
        {
            dataGridViewMaterials.Rows.Clear();
            
            foreach (var material in materials)
            {
                dataGridViewMaterials.Rows.Add(
                    material.MaterialName,
                    material.Quantity.ToString("F4"),
                    material.Unit,
                    material.Cost.ToString("F2"),
                    material.TotalCost.ToString("F2")
                );
            }

            // Расчет общей стоимости материалов
            decimal totalCost = 0;
            foreach (var material in materials)
            {
                totalCost += material.TotalCost;
            }
            
            lblTotalCost.Text = $"Общая стоимость материалов: {totalCost:F2} р";
        }

        /// <summary>
        /// Обработчик нажатия кнопки "Назад"
        /// </summary>
        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        /// <summary>
        /// Обработчик нажатия кнопки "Закрыть"
        /// </summary>
        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
} 