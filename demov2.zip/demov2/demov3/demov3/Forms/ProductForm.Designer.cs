using System.Drawing;
using System.Windows.Forms;

namespace demov3.Forms
{
    partial class ProductForm
    {
        private System.ComponentModel.IContainer components = null;
        private Panel panelHeader;
        private Label lblTitle;
        private Panel panelContent;
        private Label lblArticle;
        private TextBox txtArticle;
        private Label lblProductType;
        private ComboBox cmbProductType;
        private Label lblName;
        private TextBox txtName;
        private Label lblDescription;
        private TextBox txtDescription;
        private Label lblMinCost;
        private NumericUpDown numMinCost;
        private Label lblRollWidth;
        private NumericUpDown numRollWidth;
        private Button btnSave;
        private Button btnCancel;
        private Button btnBack;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.panelHeader = new Panel();
            this.lblTitle = new Label();
            this.panelContent = new Panel();
            this.lblArticle = new Label();
            this.txtArticle = new TextBox();
            this.lblProductType = new Label();
            this.cmbProductType = new ComboBox();
            this.lblName = new Label();
            this.txtName = new TextBox();
            this.lblDescription = new Label();
            this.txtDescription = new TextBox();
            this.lblMinCost = new Label();
            this.numMinCost = new NumericUpDown();
            this.lblRollWidth = new Label();
            this.numRollWidth = new NumericUpDown();
            this.btnSave = new Button();
            this.btnCancel = new Button();
            this.btnBack = new Button();
            this.panelHeader.SuspendLayout();
            this.panelContent.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numMinCost)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numRollWidth)).BeginInit();
            this.SuspendLayout();

            // panelHeader
            this.panelHeader.BackColor = ColorTranslator.FromHtml("#BBD9B2");
            this.panelHeader.Controls.Add(this.lblTitle);
            this.panelHeader.Dock = DockStyle.Top;
            this.panelHeader.Location = new Point(0, 0);
            this.panelHeader.Name = "panelHeader";
            this.panelHeader.Size = new Size(500, 60);
            this.panelHeader.TabIndex = 0;

            // lblTitle
            this.lblTitle.AutoSize = true;
            this.lblTitle.Font = new Font("Gabriola", 18F, FontStyle.Bold);
            this.lblTitle.ForeColor = ColorTranslator.FromHtml("#2D6033");
            this.lblTitle.Location = new Point(20, 15);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new Size(200, 30);
            this.lblTitle.TabIndex = 0;
            this.lblTitle.Text = "Добавление продукта";

            // panelContent
            this.panelContent.BackColor = Color.White;
            this.panelContent.Controls.Add(this.lblArticle);
            this.panelContent.Controls.Add(this.txtArticle);
            this.panelContent.Controls.Add(this.lblProductType);
            this.panelContent.Controls.Add(this.cmbProductType);
            this.panelContent.Controls.Add(this.lblName);
            this.panelContent.Controls.Add(this.txtName);
            this.panelContent.Controls.Add(this.lblDescription);
            this.panelContent.Controls.Add(this.txtDescription);
            this.panelContent.Controls.Add(this.lblMinCost);
            this.panelContent.Controls.Add(this.numMinCost);
            this.panelContent.Controls.Add(this.lblRollWidth);
            this.panelContent.Controls.Add(this.numRollWidth);
            this.panelContent.Controls.Add(this.btnSave);
            this.panelContent.Controls.Add(this.btnCancel);
            this.panelContent.Controls.Add(this.btnBack);
            this.panelContent.Dock = DockStyle.Fill;
            this.panelContent.Location = new Point(0, 60);
            this.panelContent.Name = "panelContent";
            this.panelContent.Size = new Size(500, 440);
            this.panelContent.TabIndex = 1;

            // lblArticle
            this.lblArticle.AutoSize = true;
            this.lblArticle.Font = new Font("Gabriola", 14F, FontStyle.Bold);
            this.lblArticle.ForeColor = ColorTranslator.FromHtml("#2D6033");
            this.lblArticle.Location = new Point(20, 20);
            this.lblArticle.Name = "lblArticle";
            this.lblArticle.Size = new Size(80, 25);
            this.lblArticle.TabIndex = 0;
            this.lblArticle.Text = "Артикул:";

            // txtArticle
            this.txtArticle.Font = new Font("Gabriola", 12F);
            this.txtArticle.Location = new Point(20, 50);
            this.txtArticle.Name = "txtArticle";
            this.txtArticle.Size = new Size(200, 30);
            this.txtArticle.TabIndex = 1;

            // lblProductType
            this.lblProductType.AutoSize = true;
            this.lblProductType.Font = new Font("Gabriola", 14F, FontStyle.Bold);
            this.lblProductType.ForeColor = ColorTranslator.FromHtml("#2D6033");
            this.lblProductType.Location = new Point(250, 20);
            this.lblProductType.Name = "lblProductType";
            this.lblProductType.Size = new Size(120, 25);
            this.lblProductType.TabIndex = 2;
            this.lblProductType.Text = "Тип продукта:";

            // cmbProductType
            this.cmbProductType.DropDownStyle = ComboBoxStyle.DropDownList;
            this.cmbProductType.Font = new Font("Gabriola", 12F);
            this.cmbProductType.Location = new Point(250, 50);
            this.cmbProductType.Name = "cmbProductType";
            this.cmbProductType.Size = new Size(220, 30);
            this.cmbProductType.TabIndex = 3;

            // lblName
            this.lblName.AutoSize = true;
            this.lblName.Font = new Font("Gabriola", 14F, FontStyle.Bold);
            this.lblName.ForeColor = ColorTranslator.FromHtml("#2D6033");
            this.lblName.Location = new Point(20, 100);
            this.lblName.Name = "lblName";
            this.lblName.Size = new Size(120, 25);
            this.lblName.TabIndex = 4;
            this.lblName.Text = "Наименование:";

            // txtName
            this.txtName.Font = new Font("Gabriola", 12F);
            this.txtName.Location = new Point(20, 130);
            this.txtName.Name = "txtName";
            this.txtName.Size = new Size(450, 30);
            this.txtName.TabIndex = 5;

            // lblDescription
            this.lblDescription.AutoSize = true;
            this.lblDescription.Font = new Font("Gabriola", 14F, FontStyle.Bold);
            this.lblDescription.ForeColor = ColorTranslator.FromHtml("#2D6033");
            this.lblDescription.Location = new Point(20, 180);
            this.lblDescription.Name = "lblDescription";
            this.lblDescription.Size = new Size(90, 25);
            this.lblDescription.TabIndex = 6;
            this.lblDescription.Text = "Описание:";

            // txtDescription
            this.txtDescription.Font = new Font("Gabriola", 12F);
            this.txtDescription.Location = new Point(20, 210);
            this.txtDescription.Multiline = true;
            this.txtDescription.Name = "txtDescription";
            this.txtDescription.Size = new Size(450, 60);
            this.txtDescription.TabIndex = 7;

            // lblMinCost
            this.lblMinCost.AutoSize = true;
            this.lblMinCost.Font = new Font("Gabriola", 14F, FontStyle.Bold);
            this.lblMinCost.ForeColor = ColorTranslator.FromHtml("#2D6033");
            this.lblMinCost.Location = new Point(20, 290);
            this.lblMinCost.Name = "lblMinCost";
            this.lblMinCost.Size = new Size(250, 25);
            this.lblMinCost.TabIndex = 8;
            this.lblMinCost.Text = "Минимальная стоимость для партнера (р):";

            // numMinCost
            this.numMinCost.DecimalPlaces = 2;
            this.numMinCost.Font = new Font("Gabriola", 12F);
            this.numMinCost.Location = new Point(20, 320);
            this.numMinCost.Maximum = new decimal(new int[] { 999999, 0, 0, 0 });
            this.numMinCost.Name = "numMinCost";
            this.numMinCost.Size = new Size(200, 30);
            this.numMinCost.TabIndex = 9;

            // lblRollWidth
            this.lblRollWidth.AutoSize = true;
            this.lblRollWidth.Font = new Font("Gabriola", 14F, FontStyle.Bold);
            this.lblRollWidth.ForeColor = ColorTranslator.FromHtml("#2D6033");
            this.lblRollWidth.Location = new Point(250, 290);
            this.lblRollWidth.Name = "lblRollWidth";
            this.lblRollWidth.Size = new Size(120, 25);
            this.lblRollWidth.TabIndex = 10;
            this.lblRollWidth.Text = "Ширина (м):";

            // numRollWidth
            this.numRollWidth.DecimalPlaces = 2;
            this.numRollWidth.Font = new Font("Gabriola", 12F);
            this.numRollWidth.Location = new Point(250, 320);
            this.numRollWidth.Maximum = new decimal(new int[] { 100, 0, 0, 0 });
            this.numRollWidth.Name = "numRollWidth";
            this.numRollWidth.Size = new Size(120, 30);
            this.numRollWidth.TabIndex = 11;

            // btnSave
            this.btnSave.BackColor = ColorTranslator.FromHtml("#2D6033");
            this.btnSave.FlatStyle = FlatStyle.Flat;
            this.btnSave.Font = new Font("Gabriola", 14F, FontStyle.Bold);
            this.btnSave.ForeColor = Color.White;
            this.btnSave.Location = new Point(20, 370);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new Size(120, 40);
            this.btnSave.TabIndex = 12;
            this.btnSave.Text = "Сохранить";
            this.btnSave.UseVisualStyleBackColor = false;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);

            // btnCancel
            this.btnCancel.BackColor = ColorTranslator.FromHtml("#BBD9B2");
            this.btnCancel.FlatStyle = FlatStyle.Flat;
            this.btnCancel.Font = new Font("Gabriola", 14F, FontStyle.Bold);
            this.btnCancel.ForeColor = ColorTranslator.FromHtml("#2D6033");
            this.btnCancel.Location = new Point(160, 370);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new Size(120, 40);
            this.btnCancel.TabIndex = 13;
            this.btnCancel.Text = "Отмена";
            this.btnCancel.UseVisualStyleBackColor = false;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);

            // btnBack
            this.btnBack.BackColor = ColorTranslator.FromHtml("#BBD9B2");
            this.btnBack.FlatStyle = FlatStyle.Flat;
            this.btnBack.Font = new Font("Gabriola", 14F, FontStyle.Bold);
            this.btnBack.ForeColor = ColorTranslator.FromHtml("#2D6033");
            this.btnBack.Location = new Point(350, 370);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new Size(120, 40);
            this.btnBack.TabIndex = 14;
            this.btnBack.Text = "Назад";
            this.btnBack.UseVisualStyleBackColor = false;
            this.btnBack.Click += new System.EventHandler(this.btnBack_Click);

            // ProductForm
            this.AutoScaleDimensions = new SizeF(6F, 13F);
            this.AutoScaleMode = AutoScaleMode.Font;
            this.BackColor = Color.White;
            this.ClientSize = new Size(500, 500);
            this.Controls.Add(this.panelContent);
            this.Controls.Add(this.panelHeader);
            this.Font = new Font("Gabriola", 12F);
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "ProductForm";
            this.StartPosition = FormStartPosition.CenterParent;
            this.Text = "Продукт";
            this.panelHeader.ResumeLayout(false);
            this.panelHeader.PerformLayout();
            this.panelContent.ResumeLayout(false);
            this.panelContent.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numMinCost)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numRollWidth)).EndInit();
            this.ResumeLayout(false);
        }
    }
} 