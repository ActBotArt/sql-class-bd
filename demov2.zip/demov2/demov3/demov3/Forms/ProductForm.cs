using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using demov3.Data;
using demov3.Models;

namespace demov3.Forms
{
    /// <summary>
    /// Форма для добавления и редактирования продукции
    /// </summary>
    public partial class ProductForm : Form
    {
        private DatabaseHelper databaseHelper;
        private Product currentProduct;
        private List<ProductType> productTypes;
        private bool isEditMode;

        public ProductForm(Product product = null)
        {
            InitializeComponent();
            databaseHelper = new DatabaseHelper();
            currentProduct = product;
            isEditMode = product != null;
            
            SetupForm();
            LoadProductTypes();
            
            if (isEditMode)
            {
                LoadProductData();
            }
        }

        /// <summary>
        /// Настройка внешнего вида формы
        /// </summary>
        private void SetupForm()
        {
            this.Text = isEditMode ? "Редактирование продукта" : "Добавление продукта";
            this.BackColor = Color.White;
            this.Font = new Font("Gabriola", 12F, FontStyle.Regular);
            this.StartPosition = FormStartPosition.CenterParent;
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
        }

        /// <summary>
        /// Загрузка типов продукции в ComboBox
        /// </summary>
        private void LoadProductTypes()
        {
            try
            {
                productTypes = databaseHelper.GetProductTypes();
                cmbProductType.DataSource = productTypes;
                cmbProductType.DisplayMember = "TypeName";
                cmbProductType.ValueMember = "Id";
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при загрузке типов продукции: {ex.Message}", 
                    "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        /// <summary>
        /// Загрузка данных продукта для редактирования
        /// </summary>
        private void LoadProductData()
        {
            if (currentProduct != null)
            {
                txtArticle.Text = currentProduct.Article;
                txtName.Text = currentProduct.Name;
                txtDescription.Text = currentProduct.Description;
                numMinCost.Value = currentProduct.MinPartnerCost;
                numRollWidth.Value = currentProduct.RollWidth;
                
                // Установка типа продукции
                cmbProductType.SelectedValue = currentProduct.ProductTypeId;
            }
        }

        /// <summary>
        /// Валидация введенных данных
        /// </summary>
        private bool ValidateInput()
        {
            // Проверка артикула
            if (string.IsNullOrWhiteSpace(txtArticle.Text))
            {
                MessageBox.Show("Артикул не может быть пустым.", 
                    "Ошибка валидации", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtArticle.Focus();
                return false;
            }

            // Проверка наименования
            if (string.IsNullOrWhiteSpace(txtName.Text))
            {
                MessageBox.Show("Наименование не может быть пустым.", 
                    "Ошибка валидации", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtName.Focus();
                return false;
            }

            // Проверка типа продукции
            if (cmbProductType.SelectedValue == null)
            {
                MessageBox.Show("Выберите тип продукции.", 
                    "Ошибка валидации", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                cmbProductType.Focus();
                return false;
            }

            // Проверка минимальной стоимости
            if (numMinCost.Value <= 0)
            {
                MessageBox.Show("Минимальная стоимость должна быть больше нуля.", 
                    "Ошибка валидации", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                numMinCost.Focus();
                return false;
            }

            // Проверка ширины рулона
            if (numRollWidth.Value <= 0)
            {
                MessageBox.Show("Ширина рулона должна быть больше нуля.", 
                    "Ошибка валидации", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                numRollWidth.Focus();
                return false;
            }

            return true;
        }

        /// <summary>
        /// Обработчик нажатия кнопки "Сохранить"
        /// </summary>
        private void btnSave_Click(object sender, EventArgs e)
        {
            if (!ValidateInput())
                return;

            try
            {
                var product = new Product
                {
                    Article = txtArticle.Text.Trim(),
                    ProductTypeId = (int)cmbProductType.SelectedValue,
                    Name = txtName.Text.Trim(),
                    Description = txtDescription.Text.Trim(),
                    MinPartnerCost = numMinCost.Value,
                    RollWidth = numRollWidth.Value,
                    ProductionTime = 0, // Значение по умолчанию
                    WorkshopNumber = 1, // Значение по умолчанию
                    WorkersCount = 1 // Значение по умолчанию
                };

                if (isEditMode)
                {
                    product.Id = currentProduct.Id;
                    databaseHelper.UpdateProduct(product);
                    MessageBox.Show("Продукт успешно обновлен.", 
                        "Успех", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    databaseHelper.AddProduct(product);
                    MessageBox.Show("Продукт успешно добавлен.", 
                        "Успех", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }

                this.DialogResult = DialogResult.OK;
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при сохранении продукта: {ex.Message}", 
                    "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        /// <summary>
        /// Обработчик нажатия кнопки "Отмена"
        /// </summary>
        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
            this.Close();
        }

        /// <summary>
        /// Обработчик нажатия кнопки "Назад"
        /// </summary>
        private void btnBack_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
            this.Close();
        }
    }
} 