using System;

namespace demov3.Models
{
    /// <summary>
    /// Модель продукции компании
    /// </summary>
    public class Product
    {
        public int Id { get; set; }
        public string Article { get; set; }
        public int ProductTypeId { get; set; }
        public string ProductType { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public decimal MinPartnerCost { get; set; }
        public decimal RollWidth { get; set; }
        public decimal MaterialCost { get; set; }
        public int ProductionTime { get; set; }
        public int WorkshopNumber { get; set; }
        public int WorkersCount { get; set; }

        /// <summary>
        /// Рассчитанная стоимость продукта (материалы + минимальная стоимость для партнера)
        /// </summary>
        public decimal CalculatedCost => Math.Round(MaterialCost + MinPartnerCost, 2);

        /// <summary>
        /// Отображаемая информация о продукте
        /// </summary>
        public string DisplayInfo => $"{Article} | {Name} - {CalculatedCost:F2} р";
    }
} 