namespace demov3.Models
{
    /// <summary>
    /// Модель связи продукции и материалов
    /// </summary>
    public class ProductMaterial
    {
        public int ProductId { get; set; }
        public string Article { get; set; }
        public string ProductName { get; set; }
        public string MaterialName { get; set; }
        public decimal Quantity { get; set; }
        public string Unit { get; set; }
        public decimal Cost { get; set; }
        public decimal TotalCost { get; set; }
    }
} 