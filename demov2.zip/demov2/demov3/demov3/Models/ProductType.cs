namespace demov3.Models
{
    /// <summary>
    /// Модель типа продукции
    /// </summary>
    public class ProductType
    {
        public int Id { get; set; }
        public string TypeName { get; set; }
        public decimal Coefficient { get; set; }

        public override string ToString()
        {
            return TypeName;
        }
    }
} 