using System;
using Microsoft.Data.SqlClient;

namespace demov3.Utils
{
    /// <summary>
    /// Класс для расчета необходимого количества материалов
    /// </summary>
    public static class MaterialCalculator
    {
        private static readonly string connectionString = @"Data Source=Uz1ps\SQLEXPRESS;Initial Catalog=WallpaperProduction;Integrated Security=True;TrustServerCertificate=True";

        /// <summary>
        /// Расчет необходимого количества материала для производства продукции
        /// </summary>
        /// <param name="productTypeId">Идентификатор типа продукции</param>
        /// <param name="materialTypeId">Идентификатор типа материала</param>
        /// <param name="productQuantity">Количество получаемой продукции</param>
        /// <param name="parameter1">Первый параметр продукции (например, длина)</param>
        /// <param name="parameter2">Второй параметр продукции (например, ширина)</param>
        /// <param name="stockQuantity">Количество материала на складе</param>
        /// <returns>Количество необходимого материала с учетом брака или -1 при ошибке</returns>
        public static int CalculateMaterialNeed(
            int productTypeId,
            int materialTypeId,
            int productQuantity,
            decimal parameter1,
            decimal parameter2,
            decimal stockQuantity)
        {
            // Проверка входных параметров
            if (productQuantity <= 0 || parameter1 <= 0 || parameter2 <= 0 || stockQuantity < 0)
            {
                return -1;
            }

            try
            {
                using (var connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    
                    // Вызов функции из базы данных
                    string query = "SELECT dbo.CalculateMaterialNeed(@ProductTypeId, @MaterialTypeId, @ProductQuantity, @Parameter1, @Parameter2, @StockQuantity)";
                    
                    using (var command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@ProductTypeId", productTypeId);
                        command.Parameters.AddWithValue("@MaterialTypeId", materialTypeId);
                        command.Parameters.AddWithValue("@ProductQuantity", productQuantity);
                        command.Parameters.AddWithValue("@Parameter1", parameter1);
                        command.Parameters.AddWithValue("@Parameter2", parameter2);
                        command.Parameters.AddWithValue("@StockQuantity", stockQuantity);
                        
                        var result = command.ExecuteScalar();
                        return result != null ? Convert.ToInt32(result) : -1;
                    }
                }
            }
            catch (Exception)
            {
                return -1;
            }
        }

        /// <summary>
        /// Альтернативная реализация расчета материала без использования функции БД
        /// </summary>
        public static int CalculateMaterialNeedLocal(
            int productTypeId,
            int materialTypeId,
            int productQuantity,
            decimal parameter1,
            decimal parameter2,
            decimal stockQuantity)
        {
            // Проверка входных параметров
            if (productQuantity <= 0 || parameter1 <= 0 || parameter2 <= 0 || stockQuantity < 0)
            {
                return -1;
            }

            try
            {
                decimal coefficient = 1.0m;
                decimal wastePercentage = 0.0m;

                using (var connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    
                    // Получение коэффициента типа продукции
                    string productTypeQuery = "SELECT Coefficient FROM ProductTypes WHERE Id = @ProductTypeId";
                    using (var command = new SqlCommand(productTypeQuery, connection))
                    {
                        command.Parameters.AddWithValue("@ProductTypeId", productTypeId);
                        var result = command.ExecuteScalar();
                        if (result == null) return -1;
                        coefficient = Convert.ToDecimal(result);
                    }
                    
                    // Получение процента брака материала
                    string materialTypeQuery = "SELECT WastePercentage FROM MaterialTypes WHERE Id = @MaterialTypeId";
                    using (var command = new SqlCommand(materialTypeQuery, connection))
                    {
                        command.Parameters.AddWithValue("@MaterialTypeId", materialTypeId);
                        var result = command.ExecuteScalar();
                        if (result == null) return -1;
                        wastePercentage = Convert.ToDecimal(result);
                    }
                }

                // Расчет необходимого количества материала на единицу продукции
                decimal requiredQuantity = parameter1 * parameter2 * coefficient;
                
                // Учет брака материала
                decimal totalRequired = requiredQuantity * productQuantity * (1 + wastePercentage / 100.0m);
                
                // Учет материала на складе
                totalRequired = totalRequired - stockQuantity;
                
                // Возврат целого количества (округление вверх)
                if (totalRequired <= 0)
                    return 0;
                else
                    return (int)Math.Ceiling(totalRequired);
            }
            catch (Exception)
            {
                return -1;
            }
        }
    }
} 