using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using demov4.Models;

namespace demov4.Data
{
    /// <summary>
    /// Класс для работы с базой данных
    /// </summary>
    public class DatabaseHelper
    {
        private readonly string connectionString;

        public DatabaseHelper()
        {
            connectionString = @"Data Source=Uz1ps\SQLEXPRESS;Initial Catalog=FurnitureCompany;Integrated Security=True;TrustServerCertificate=True";
        }

        /// <summary>
        /// Получение списка всех продуктов с временем изготовления
        /// </summary>
        public List<Product> GetAllProducts()
        {
            var products = new List<Product>();

            try
            {
                using (var connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string query = @"SELECT p.ProductId, p.Article, pt.TypeName as ProductType, p.ProductName, 
                                           p.MinCostForPartner, p.MainMaterial, 
                                           ISNULL(SUM(pw.ManufacturingTime), 0) AS TotalManufacturingTime
                                    FROM Products p
                                    LEFT JOIN ProductTypes pt ON p.ProductTypeId = pt.ProductTypeId
                                    LEFT JOIN ProductWorkshops pw ON p.ProductId = pw.ProductId
                                    GROUP BY p.ProductId, p.Article, pt.TypeName, p.ProductName, p.MinCostForPartner, p.MainMaterial
                                    ORDER BY p.ProductName";

                    using (var command = new SqlCommand(query, connection))
                    using (var reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            products.Add(new Product
                            {
                                ProductId = reader.GetInt32(0),
                                Article = reader.IsDBNull(1) ? string.Empty : reader.GetString(1),
                                ProductType = reader.IsDBNull(2) ? string.Empty : reader.GetString(2),
                                ProductName = reader.IsDBNull(3) ? string.Empty : reader.GetString(3),
                                MinCostForPartner = reader.IsDBNull(4) ? 0 : reader.GetDecimal(4),
                                MainMaterial = reader.IsDBNull(5) ? string.Empty : reader.GetString(5),
                                TotalManufacturingTime = reader.IsDBNull(6) ? 0 : reader.GetDecimal(6)
                            });
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception($"Ошибка при получении списка продукции: {ex.Message}");
            }

            return products;
        }

        /// <summary>
        /// Получение продукта по ID
        /// </summary>
        public Product GetProductById(int productId)
        {
            try
            {
                using (var connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string query = @"SELECT p.ProductId, p.Article, p.ProductTypeId, p.ProductName, p.MinCostForPartner, p.MainMaterial, pt.TypeName as ProductType 
                                   FROM Products p 
                                   JOIN ProductTypes pt ON p.ProductTypeId = pt.ProductTypeId 
                                   WHERE p.ProductId = @ProductId";

                    using (var command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@ProductId", productId);
                        using (var reader = command.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                return new Product
                                {
                                    ProductId = reader.GetInt32(0),
                                    Article = reader.IsDBNull(1) ? string.Empty : reader.GetString(1),
                                    ProductTypeId = reader.GetInt32(2),
                                    ProductName = reader.IsDBNull(3) ? string.Empty : reader.GetString(3),
                                    MinCostForPartner = reader.IsDBNull(4) ? 0 : reader.GetDecimal(4),
                                    MainMaterial = reader.IsDBNull(5) ? string.Empty : reader.GetString(5),
                                    ProductType = reader.IsDBNull(6) ? string.Empty : reader.GetString(6)
                                };
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception($"Ошибка при получении продукта: {ex.Message}");
            }

            return null;
        }

        /// <summary>
        /// Получение списка типов продукции
        /// </summary>
        public List<ProductType> GetProductTypes()
        {
            var productTypes = new List<ProductType>();

            try
            {
                using (var connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string query = "SELECT ProductTypeId, TypeName, TypeCoefficient FROM ProductTypes ORDER BY TypeName";

                    using (var command = new SqlCommand(query, connection))
                    using (var reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            productTypes.Add(new ProductType
                            {
                                ProductTypeId = reader.GetInt32(0),
                                TypeName = reader.IsDBNull(1) ? string.Empty : reader.GetString(1),
                                TypeCoefficient = reader.IsDBNull(2) ? 0 : reader.GetDecimal(2)
                            });
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception($"Ошибка при получении типов продукции: {ex.Message}");
            }

            return productTypes;
        }

        /// <summary>
        /// Добавление нового продукта
        /// </summary>
        public void AddProduct(Product product)
        {
            try
            {
                using (var connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string query = @"INSERT INTO Products (Article, ProductTypeId, ProductName, MinCostForPartner, MainMaterial) 
                                   VALUES (@Article, @ProductTypeId, @ProductName, @MinCostForPartner, @MainMaterial)";

                    using (var command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@Article", product.Article);
                        command.Parameters.AddWithValue("@ProductTypeId", product.ProductTypeId);
                        command.Parameters.AddWithValue("@ProductName", product.ProductName);
                        command.Parameters.AddWithValue("@MinCostForPartner", product.MinCostForPartner);
                        command.Parameters.AddWithValue("@MainMaterial", product.MainMaterial);

                        command.ExecuteNonQuery();
                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception($"Ошибка при добавлении продукта: {ex.Message}");
            }
        }

        /// <summary>
        /// Обновление продукта
        /// </summary>
        public void UpdateProduct(Product product)
        {
            try
            {
                using (var connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string query = @"UPDATE Products 
                                   SET Article = @Article, ProductTypeId = @ProductTypeId, 
                                       ProductName = @ProductName, MinCostForPartner = @MinCostForPartner, 
                                       MainMaterial = @MainMaterial 
                                   WHERE ProductId = @ProductId";

                    using (var command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@ProductId", product.ProductId);
                        command.Parameters.AddWithValue("@Article", product.Article);
                        command.Parameters.AddWithValue("@ProductTypeId", product.ProductTypeId);
                        command.Parameters.AddWithValue("@ProductName", product.ProductName);
                        command.Parameters.AddWithValue("@MinCostForPartner", product.MinCostForPartner);
                        command.Parameters.AddWithValue("@MainMaterial", product.MainMaterial);

                        command.ExecuteNonQuery();
                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception($"Ошибка при обновлении продукта: {ex.Message}");
            }
        }

        /// <summary>
        /// Получение списка цехов для конкретного продукта
        /// </summary>
        public List<Workshop> GetWorkshopsForProduct(int productId)
        {
            var workshops = new List<Workshop>();

            try
            {
                using (var connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string query = @"SELECT w.WorkshopId, w.WorkshopName, w.WorkshopType, w.PeopleCount, pw.ManufacturingTime
                                   FROM Workshops w
                                   JOIN ProductWorkshops pw ON w.WorkshopId = pw.WorkshopId
                                   WHERE pw.ProductId = @ProductId
                                   ORDER BY w.WorkshopName";

                    using (var command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@ProductId", productId);
                        using (var reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                workshops.Add(new Workshop
                                {
                                    WorkshopId = reader.GetInt32(0),
                                    WorkshopName = reader.IsDBNull(1) ? string.Empty : reader.GetString(1),
                                    WorkshopType = reader.IsDBNull(2) ? string.Empty : reader.GetString(2),
                                    PeopleCount = reader.GetInt32(3),
                                    ManufacturingTime = reader.IsDBNull(4) ? 0 : reader.GetDecimal(4)
                                });
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception($"Ошибка при получении списка цехов: {ex.Message}");
            }

            return workshops;
        }

        /// <summary>
        /// Проверка подключения к базе данных
        /// </summary>
        public bool TestConnection()
        {
            try
            {
                using (var connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    return true;
                }
            }
            catch
            {
                return false;
            }
        }
    }
} 