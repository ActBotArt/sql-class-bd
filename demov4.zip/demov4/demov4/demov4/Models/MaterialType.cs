namespace demov4.Models
{
    /// <summary>
    /// Модель типа материала
    /// </summary>
    public class MaterialType
    {
        public int MaterialTypeId { get; set; }
        public string MaterialName { get; set; }
        public decimal WastagePercentage { get; set; }
    }
} 